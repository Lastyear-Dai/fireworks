import * as THREE from "three"
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls'
// 导入变换控制器
import { TransformControls } from "three/addons/controls/TransformControls.js";



//1. 创建场景
const scene = new THREE.Scene()
//2. 创建相机 1角度;    2.视口宽高比;   3,近端0.1;   4.远端1000
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 10000)
// 位置
camera.position.set(0, 0, 120);
// 将相机添加到场景当中
scene.add(camera);

// 设置背景颜色为白色
// scene.background = new THREE.Color(0xffffff);

//初始化渲染器
const renderer = new THREE.WebGLRenderer()
//设置渲染的尺寸大小
renderer.setSize(window.innerWidth, window.innerHeight);
// console.log(renderer)
//将webgl渲染的canvas内容添加到body
document.body.appendChild(renderer.domElement)

//创建轨道控制器
const controls = new OrbitControls(camera, renderer.domElement);
// 添加网格辅助器
const gridHelper = new THREE.GridHelper(1000, 1000);
gridHelper.material.opacity = 0.3;
gridHelper.material.transparent = true;
scene.add(gridHelper);

//螺旋丸参数
const luoxuanwan = {
  dingdian: 20000,//10000个顶点
  radius: 50,//螺旋丸半径
  branch: 3,//3条棱

}
//创建顶点对象
const geometry = new THREE.BufferGeometry();
//创建一个顶点数组
const vertices = new Float32Array(luoxuanwan.dingdian * 3)
//赋值
for (let i = 0; i < luoxuanwan.dingdian; i++) {
  //当前半径
  let currentBranch = Math.random() * luoxuanwan.radius
  const currentIndex = i * 3
  //当前角度
  let angle = Math.PI * 2 / luoxuanwan.branch * (i % luoxuanwan.branch) + currentBranch / luoxuanwan.radius
  //每条棱的粗或细
  let chuX = Math.pow(Math.random() * 6 - 3, 3) * (luoxuanwan.radius - currentBranch) / luoxuanwan.radius;
  let chuY = Math.pow(Math.random() * 6 - 3, 3) * (luoxuanwan.radius - currentBranch) / luoxuanwan.radius;
  let chuZ = Math.pow(Math.random() * 6 - 3, 3) * (luoxuanwan.radius - currentBranch) / luoxuanwan.radius;

  vertices[currentIndex] = Math.sin(angle) * currentBranch + chuX
  vertices[currentIndex + 1] = 0 + chuY
  vertices[currentIndex + 2] = Math.cos(angle) * currentBranch + chuZ

}

console.log(vertices)
//设置顶点位置
geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
// 设置点材质
const pointsMaterial = new THREE.PointsMaterial();
pointsMaterial.size = 0.1;
pointsMaterial.color.set(0xffffff);
// // 相机深度而衰减
// pointsMaterial.sizeAttenuation = true;
// // 载入纹理
// const textureLoader = new THREE.TextureLoader();
// const texture = textureLoader.load("./public/texture/雪花.png");
// const texture1 = textureLoader.load("./public/texture/雪花-透明贴图.png");
// pointsMaterial.map = texture;
// pointsMaterial.alphaMap = texture1;
// pointsMaterial.transparent = true
// //关闭深度缓存
// pointsMaterial.depthWrite = false;
// //开启混合模式的叠加颜色算法
// pointsMaterial.blending = THREE.AdditiveBlending;
const points = new THREE.Points(geometry, pointsMaterial);

scene.add(points);

// 设置时钟
const clock = new THREE.Clock();
// 自定以一个函数
function render () {
  let time = clock.getElapsedTime();
  // points.rotation.x = time * 0.4;
  points.rotation.y = -time * 10;
  renderer.render(scene, camera);
  //做到无限渲染
  requestAnimationFrame(render);
}
render();
